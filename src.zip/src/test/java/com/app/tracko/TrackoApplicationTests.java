package com.app.tracko;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrackoApplicationTests {

	@Test
	void contextLoads() {
	}

}
