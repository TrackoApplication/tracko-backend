package com.app.tracko.service;

import com.app.tracko.entity.AccessGroupEntity;
import com.app.tracko.model.AccessGroup;

import java.util.List;

public class AccessGroupServiceImpl implements AccessGroupService {

}
