package com.app.tracko.entity;

public enum Status {
    TO_DO,
    IN_PROGRESS,
    COMPLETED ;
}
